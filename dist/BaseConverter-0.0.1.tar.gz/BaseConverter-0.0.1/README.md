# BaseConverter

This is a simple example of converting numbers to different bases.
